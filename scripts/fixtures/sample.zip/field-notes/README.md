# Field notes

Captured for the weekly report.
